import { checkCooldown } from "../core/cooldowns.js";
import { env } from "../core/env.js";
import { rootLogger } from "../core/logger.js";
import { isTicketChannel, getTicketMeta } from "./ticketHandler.js";
import { isSalaryChannel } from "./salaryHandler.js";
import { isStaffMember } from "../utils/modHelpers.js";
import { createEmbed } from "../utils/brand.js";
import { groqChat, groqVision, parseJsonFromAi, isGroqConfigured } from "../services/groqChat.js";
import {
  buildTicketAiSystemPrompt,
  buildGeneralAiSystemPrompt,
  EXTRACT_WORK_PROMPT,
  INVOICE_SCAN_PROMPT,
} from "../utils/aiContext.js";
import {
  buildCombinedQuote,
  tilbudEmbed,
  formatKr,
} from "../utils/quoteBuilder.js";
import { getPartsPriceStore } from "../utils/partsPriceStore.js";
import { collectMessageImageUrls, messageHasImages } from "../utils/messageImages.js";
import { JG_MARKUP_PERCENT } from "../config/jgParts.js";

const AI_COOLDOWN_MS = 12_000;
const PAYROLL_AUTO_COOLDOWN_MS = 8_000;
const payrollProcessedIds = new Set();

function aiHelpEmbed() {
  return createEmbed("accent")
    .setTitle("🤖 Benny's AI")
    .setDescription("Spørg kun om **Benny's** — priser, ydelser, regler og mekaniker-RP.")
    .addFields(
      { name: "Spørgsmål", value: "`,ai Hvad koster bugsering?`\n`,ai Forklar JG tuning`", inline: false },
      { name: "Beregn tilbud", value: "`,ai tilbud V8 motor og keramiske bremser`", inline: false },
      { name: "Faktura (staff)", value: "Upload screenshot i `#💰-løn-[navn]` — botten svarer med **lønbeløb**", inline: false },
      { name: "Staff", value: "`,tilbud smart <beskrivelse>`", inline: false }
    );
}

async function extractWorkItems(description) {
  const raw = await groqChat(
    [{ role: "user", content: EXTRACT_WORK_PROMPT(description) }],
    { json: true, maxTokens: 512, temperature: 0.1 }
  );
  return parseJsonFromAi(raw);
}

function buildQuoteFromExtracted(extracted) {
  const partLines = [...(extracted.parts ?? [])];
  for (const m of extracted.manualParts ?? []) {
    if (m?.id && m?.price) partLines.push(`${m.id}=${m.price}`);
  }
  return buildCombinedQuote({
    partLines,
    fixedServiceKeys: extracted.services ?? [],
  });
}

export async function handleAiTilbud(message, description, { reply = true } = {}) {
  const text = description?.trim();
  if (!text) {
    if (reply) await message.reply("❌ Brug: `,ai tilbud V8 og keramiske bremser`").catch(() => {});
    return null;
  }

  const loading = reply ? await message.reply("🧮 Beregner tilbud…").catch(() => null) : null;

  try {
    const extracted = await extractWorkItems(text);
    const quote = buildQuoteFromExtracted(extracted);
    const embed = tilbudEmbed(quote, getPartsPriceStore(), { aiNote: extracted.note || undefined });

    if (loading) await loading.edit({ content: null, embeds: [embed] }).catch(() => message.reply({ embeds: [embed] }));
    else if (reply) await message.reply({ embeds: [embed] }).catch(() => {});

    return quote;
  } catch (err) {
    rootLogger.error("AI tilbud fejlede", { error: err.message });
    const msg = `❌ Kunne ikke beregne tilbud: ${err.message}`;
    if (loading) await loading.edit({ content: msg, embeds: [] }).catch(() => message.reply(msg));
    else if (reply) await message.reply(msg).catch(() => {});
    return null;
  }
}

function resolveInvoiceTotal(data) {
  return Math.round(Number(data.total ?? data.invoiceTotal ?? data.amount) || 0);
}

function resolveEmployeePay(data) {
  const total = resolveInvoiceTotal(data);
  if (total <= 0) return 0;
  return Math.round(total * (JG_MARKUP_PERCENT / 100));
}

function buildInvoiceEmbed(data) {
  const total = resolveInvoiceTotal(data);
  const employeePay = resolveEmployeePay(data);
  const confidence = data.confidence ?? "medium";

  return createEmbed(employeePay ? "gold" : confidence === "low" ? "warning" : "gold")
    .setTitle("💰 Løn")
    .setDescription(
      employeePay
        ? `**${formatKr(employeePay)}** skal udbetales til medarbejderen (**${JG_MARKUP_PERCENT}%** af faktura på ${formatKr(total)}).`
        : "❌ Kunne ikke aflæse fakturabeløb — tjek screenshot manuelt."
    );
}

/** Læs faktura-screenshot — returnerer kun medarbejderens lønbeløb */
export async function processInvoiceImages(message, { loadingMessage = null } = {}) {
  const urls = await collectMessageImageUrls(message);
  if (!urls.length) return null;

  const raw = await groqVision(INVOICE_SCAN_PROMPT, urls, { json: true });
  const data = parseJsonFromAi(raw);
  const embed = buildInvoiceEmbed(data);

  const employeePay = resolveEmployeePay(data);
  await logPayrollToDashboard(message, data, employeePay);

  if (loadingMessage) {
    await loadingMessage.edit({ content: null, embeds: [embed] }).catch(() => message.reply({ embeds: [embed] }));
  } else {
    await message.reply({ embeds: [embed] }).catch(() => {});
  }

  return { data, employeePay: resolveEmployeePay(data) };
}

async function logPayrollToDashboard(message, data, employeePay) {
  const total = resolveInvoiceTotal(data);
  if (!message.guild || employeePay <= 0) return;
  try {
    const { savePayrollLog } = await import("../services/dashboardStore.js");
    await savePayrollLog({
      guildId: message.guild.id,
      userId: message.author.id,
      userName: message.author.tag,
      invoiceTotal: total,
      employeePay,
      channelId: message.channel.id,
    });
  } catch {
    /* optional */
  }
}

async function handleAiFaktura(message) {
  if (!isStaffMember(message.member)) {
    await message.reply("❌ Kun staff kan tjekke faktura-screenshots.").catch(() => {});
    return true;
  }

  const urls = await collectMessageImageUrls(message);
  if (!urls.length) {
    await message.reply("❌ Vedhæft faktura-screenshot eller svar på et billede med `,ai faktura`.").catch(() => {});
    return true;
  }

  const loading = await message.reply("💰 Aflæser lønbeløb…").catch(() => null);

  try {
    const result = await processInvoiceImages(message, { loadingMessage: loading });
    if (!result) {
      const msg = "❌ Kunne ikke læse faktura.";
      if (loading) await loading.edit({ content: msg, embeds: [] }).catch(() => message.reply(msg));
    }
    return true;
  } catch (err) {
    rootLogger.error("AI faktura fejlede", { error: err.message });
    const msg = `❌ Faktura-scan fejlede: ${err.message}`;
    if (loading) await loading.edit({ content: msg, embeds: [] }).catch(() => message.reply(msg));
    else await message.reply(msg).catch(() => {});
    return true;
  }
}

async function handleAiQuestion(message, question) {
  const inTicket = isTicketChannel(message.channel);
  const system = inTicket
    ? buildTicketAiSystemPrompt(getTicketMeta(message.channel))
    : buildGeneralAiSystemPrompt();

  const answer = await groqChat(
    [
      { role: "system", content: system },
      { role: "user", content: question },
    ],
    { maxTokens: 800, temperature: 0.45 }
  );

  const embed = createEmbed("blue")
    .setAuthor({ name: "Benny's AI-assistent" })
    .setDescription(answer.slice(0, 4000))
    .setFooter({
      text: inTicket
        ? "Kun Benny's-spørgsmål · ved tvivl venter en mekaniker"
        : "Kun Benny's-spørgsmål · tjek vigtige oplysninger hos staff",
    });

  await message.reply({ embeds: [embed] }).catch(() => {});
}

function canUseAi(message) {
  if (isStaffMember(message.member)) return true;
  if (isTicketChannel(message.channel)) return true;
  return false;
}

export function isAiCommand(command) {
  return command === "ai" || command === "bot";
}

export async function handleTicketAi(message, rawArgs) {
  const args = Array.isArray(rawArgs) ? rawArgs : String(rawArgs ?? "").trim().split(/\s+/).filter(Boolean);
  if (!canUseAi(message)) {
    await message
      .reply("❌ `,ai` er for **staff** (alle kanaler) og **kunder i tickets**.")
      .catch(() => {});
    return true;
  }

  if (!isGroqConfigured()) {
    await message.reply("❌ AI er ikke sat op — tilføj `GROQ_API_KEY` i `.env`.").catch(() => {});
    return true;
  }

  const sub = (args[0] ?? "").toLowerCase();
  const rest = args.slice(1).join(" ").trim();

  if (!sub || sub === "help" || sub === "hjælp") {
    await message.reply({ embeds: [aiHelpEmbed()] }).catch(() => {});
    return true;
  }

  if ((sub === "tilbud" || sub === "pris" || sub === "faktura") && !isStaffMember(message.member)) {
    await message.reply("❌ Kun **staff** kan bruge `,ai tilbud` og `,ai faktura`.").catch(() => {});
    return true;
  }

  const cdKey = sub === "faktura" ? "ai-faktura" : sub === "tilbud" ? "ai-tilbud" : "ai-ask";
  const cd = checkCooldown(message.author.id, cdKey, AI_COOLDOWN_MS);
  if (!cd.allowed) {
    await message.reply(`⏳ Vent **${cd.remainingSeconds}** sek. før næste AI-forespørgsel.`).catch(() => {});
    return true;
  }

  if (sub === "tilbud" || sub === "pris" || sub === "faktura") {
    if (sub === "faktura") return handleAiFaktura(message);
    const desc = rest || message.content.replace(/^,\s*ai\s+(tilbud|pris)\s*/i, "").trim();
    await handleAiTilbud(message, desc);
    return true;
  }

  const question = args.join(" ").trim();
  if (!question) {
    await message.reply({ embeds: [aiHelpEmbed()] }).catch(() => {});
    return true;
  }

  const loading = await message.reply("💭 Tænker…").catch(() => null);

  try {
    if (loading) await loading.delete().catch(() => {});
    await handleAiQuestion(message, question);
  } catch (err) {
    rootLogger.error("AI spørgsmål fejlede", { error: err.message });
    const msg = `❌ AI fejlede: ${err.message}`;
    if (loading) await loading.edit({ content: msg }).catch(() => message.reply(msg));
    else await message.reply(msg).catch(() => {});
  }

  return true;
}

/** Auto: faktura-screenshot i #💰-løn-* kanaler */
export async function tryAutoScanPayrollInvoice(message) {
  if (!env.aiPayrollAutoScan || !isGroqConfigured()) return false;
  if (!message.guild || message.author.bot) return false;
  if (!isSalaryChannel(message.channel)) return false;
  if (!messageHasImages(message)) return false;
  if (payrollProcessedIds.has(message.id)) return false;

  const content = message.content.trim();
  if (content.startsWith(",")) return false;

  const cd = checkCooldown(message.channel.id, "payroll-invoice-auto", PAYROLL_AUTO_COOLDOWN_MS);
  if (!cd.allowed) return false;

  payrollProcessedIds.add(message.id);
  if (payrollProcessedIds.size > 500) {
    const first = payrollProcessedIds.values().next().value;
    payrollProcessedIds.delete(first);
  }

  const loading = await message.reply("💰 Aflæser lønbeløb…").catch(() => null);

  try {
    await processInvoiceImages(message, { loadingMessage: loading });
    return true;
  } catch (err) {
    rootLogger.error("Auto løn-faktura fejlede", { error: err.message });
    payrollProcessedIds.delete(message.id);
    const msg = `❌ Auto faktura-scan fejlede: ${err.message}`;
    if (loading) await loading.edit({ content: msg, embeds: [] }).catch(() => message.reply(msg));
    return true;
  }
}

/** Staff: ,tilbud smart <beskrivelse> */
export async function handleTilbudSmart(message, description) {
  if (!isStaffMember(message.member)) {
    await message.reply("❌ Kun staff.").catch(() => {});
    return true;
  }
  if (!isGroqConfigured()) {
    await message.reply("❌ AI kræver `GROQ_API_KEY`.").catch(() => {});
    return true;
  }
  await handleAiTilbud(message, description);
  return true;
}
