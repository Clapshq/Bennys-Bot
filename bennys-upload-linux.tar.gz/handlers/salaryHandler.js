import { ChannelType, PermissionFlagsBits } from "discord.js";
import { buildPersonalSalaryPermissions } from "../utils/permissions.js";
import { personalSalaryEmbed } from "../utils/embeds.js";
import {
  getStaffRoleNames,
  getLedelseRoleNames,
  memberHasLedelseRole,
} from "../config/roles.js";

export const SALARY_CHANNEL_PREFIX = "💰-løn-";
export const PAYROLL_CATEGORY = "Løn & Faktura";

function slugUsername(username) {
  return username.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20);
}

export function getSalaryChannelName(username) {
  return `${SALARY_CHANNEL_PREFIX}${slugUsername(username)}`;
}

export function isSalaryChannel(channel) {
  return Boolean(channel?.name?.startsWith(SALARY_CHANNEL_PREFIX));
}

export function isPayrollStaff(member) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return memberHasLedelseRole(member);
}

export async function ensurePayrollCategory(guild) {
  let category = guild.channels.cache.find(
    (c) => c.type === ChannelType.GuildCategory && c.name === PAYROLL_CATEGORY
  );

  if (!category) {
    category = await guild.channels.create({
      name: PAYROLL_CATEGORY,
      type: ChannelType.GuildCategory,
      permissionOverwrites: [{ id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] }],
      reason: "Benny's — løn-kategori",
    });
  }

  return category;
}

function getLedelseRoleIds(guild) {
  return getLedelseRoleNames()
    .map((name) => guild.roles.cache.find((r) => r.name === name)?.id)
    .filter(Boolean);
}

/** Opretter (eller genopretter) en personlig løn-kanal. */
export async function createPersonalSalaryChannel(guild, member, { recreate = false } = {}) {
  if (member.user.bot) {
    return { ok: false, error: "Bots kan ikke få en løn-kanal." };
  }

  const ledelseRoleIds = getLedelseRoleIds(guild);
  const channelName = getSalaryChannelName(member.user.username);
  const existing = guild.channels.cache.find((c) => c.name === channelName);

  if (existing && !recreate) {
    return {
      ok: true,
      created: false,
      channel: existing,
      message: `ℹ️ Løn-kanal findes allerede: ${existing}`,
    };
  }

  if (existing && recreate) {
    await existing.delete("Genopretter løn-kanal").catch(() => {});
  }

  const category = await ensurePayrollCategory(guild);
  const perms = buildPersonalSalaryPermissions(guild, member.id, ledelseRoleIds, guild.client.user.id);

  const channel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `Personlig løn-kanal for ${member.user.tag}`,
    permissionOverwrites: perms,
    reason: `Løn-kanal oprettet for ${member.user.tag}`,
  });

  await channel.send({ embeds: [personalSalaryEmbed(member)] });

  return {
    ok: true,
    created: true,
    channel,
    message: `✅ Løn-kanal oprettet: ${channel}`,
  };
}

export async function createAllStaffSalaryChannels(guild, roles) {
  const staffNames = getStaffRoleNames();
  const members = new Map();

  for (const name of staffNames) {
    const role = roles[name] ?? guild.roles.cache.find((r) => r.name === name);
    if (!role) continue;
    for (const member of role.members.values()) {
      if (!member.user.bot) members.set(member.id, member);
    }
  }

  let created = 0;
  for (const member of members.values()) {
    const result = await createPersonalSalaryChannel(guild, member, { recreate: true });
    if (result.created) created++;
  }

  return created;
}
