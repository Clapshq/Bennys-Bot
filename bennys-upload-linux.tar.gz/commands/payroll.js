import { SlashCommandBuilder, MessageFlags } from "discord.js";
import { createPersonalSalaryChannel, isPayrollStaff } from "../handlers/salaryHandler.js";
import { LEDelse_COMMAND_PERMISSIONS } from "../config/commandPermissions.js";

export const lonOpretCommand = {
  data: new SlashCommandBuilder()
    .setName("lønopret")
    .setDescription("Opret personlig løn-kanal — kun medarbejderen og ledelse/ejere har adgang")
    .setDefaultMemberPermissions(LEDelse_COMMAND_PERMISSIONS)
    .addUserOption((opt) =>
      opt.setName("medarbejder").setDescription("Personen der skal have løn-kanal").setRequired(true)
    )
    .addBooleanOption((opt) =>
      opt.setName("genopret").setDescription("Slet og genopret kanalen hvis den findes (standard: nej)").setRequired(false)
    ),

  async execute(interaction) {
    if (!isPayrollStaff(interaction.member)) {
      return interaction.reply({
        content: "❌ Kun **ledelse & ejere** (Stifter, Med-ejer, Ledelse) kan oprette løn-kanaler.",
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const user = interaction.options.getUser("medarbejder");
    const recreate = interaction.options.getBoolean("genopret") ?? false;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (!member) {
      return interaction.editReply({ content: "❌ Medlemmet er ikke på serveren." });
    }

    const result = await createPersonalSalaryChannel(interaction.guild, member, { recreate });

    if (!result.ok) {
      return interaction.editReply({ content: `❌ ${result.error}` });
    }

    return interaction.editReply({
      content:
        `${result.message}\n\n` +
        `👤 **${member.user.tag}**\n` +
        `🔒 Adgang: ${member} + ledelse/ejere`,
    });
  },
};
